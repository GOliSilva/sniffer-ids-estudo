"""Etapas 2 e 3: transformar o segmento TCP num Evento (versão da prova).

É o protocolos.py da aula de diagnóstico com campos a mais no Evento, para que
as regras enxerguem o cabeçalho e o payload inteiro:
  porta_origem, porta_destino, transacao, id_protocolo, unidade, tamanho,
  malformado, pareada, tempo_resposta, bruto.
E duas mudanças de comportamento:
  - mensagem Modbus com cabeçalho errado não é mais descartada: vira um Evento
    com malformado=True, para a regra poder ver;
  - valores traz todos os registradores (antes, só os 4 primeiros).
"""

import struct
from dataclasses import dataclass, field


@dataclass
class Evento:
    ts: float          # hora da captura, em segundos
    origem: str        # IP de quem mandou
    destino: str       # IP de quem recebe
    protocolo: str     # "modbus" ou "s7"
    direcao: str       # "pergunta" ou "resposta"
    operacao: str      # "leitura", "escrita", "controle", "outra"
    funcao: int        # código da função no protocolo
    area: str = ""     # Modbus: "holding", "input", "coil", "discreta"; S7: "DB1", "M", "I", "Q"
    endereco: int = 0  # Modbus: número do registrador; S7: byte dentro da área
    quantidade: int = 0
    status: int = 0    # 0 = ok; senão, código de erro
    valores: list = field(default_factory=list)
    # ---- campos novos da prova
    porta_origem: int = 0
    porta_destino: int = 0
    transacao: int = 0       # Modbus: Transaction ID; S7: PDU reference
    id_protocolo: int = 0    # Modbus: Protocol ID (sempre 0); S7: 0x32
    unidade: int = 0         # Modbus: Unit ID; S7: não tem (0)
    tamanho: int = 0         # tamanho que o cabeçalho DIZ ter (Modbus: Length; S7: TPKT)
    malformado: bool = False  # o cabeçalho não confere com o que chegou
    pareada: bool = False    # resposta: achou a pergunta dela
    tempo_resposta: float = 0.0  # resposta: segundos desde a pergunta
    bruto: bytes = b""       # o payload TCP inteiro, como chegou

    def __str__(self):
        texto = (f"{self.origem:>15} -> {self.destino:<15} "
                 f"{self.protocolo:6} {self.direcao:8} {self.operacao:9}"
                 f" f={self.funcao:#04x} {self.area} end={self.endereco}"
                 f" qtd={self.quantidade} {self.valores}"
                 f" status={self.status:#06x} tr={self.transacao}")
        if self.protocolo == "modbus":
            texto += f" uid={self.unidade}"
        if self.pareada:
            texto += f" {self.tempo_resposta * 1000:.0f}ms"
        if self.malformado:
            texto += " MALFORMADO"
        return texto


PENDENTES = {}        # perguntas esperando resposta
DECODIFICADORES = {}  # porta do servidor -> função que decodifica


def palavras(dados):
    """Todos os números de 16 bits (big-endian) de dados."""
    n = len(dados) // 2
    return list(struct.unpack(f">{n}H", dados[:n * 2]))


def decodificar(seg):
    porta = (seg.porta_destino if seg.porta_destino in DECODIFICADORES
             else seg.porta_origem)
    funcao = DECODIFICADORES.get(porta)
    return funcao(seg) if funcao else None


def novo_evento(seg, protocolo, pergunta, operacao, funcao):
    return Evento(seg.ts, seg.ip_origem, seg.ip_destino, protocolo,
                  "pergunta" if pergunta else "resposta", operacao, funcao,
                  porta_origem=seg.porta_origem,
                  porta_destino=seg.porta_destino, bruto=seg.payload)


def casar(ev, chave):
    """Resposta: busca a pergunta pela chave e copia o que a resposta não repete."""
    p = PENDENTES.pop(chave, None)
    if p:
        ev.pareada = True
        ev.tempo_resposta = ev.ts - p.ts
        ev.endereco, ev.quantidade = p.endereco, p.quantidade
    return p


MODBUS_OPERACAO = {1: "leitura", 2: "leitura", 3: "leitura",
                   4: "leitura", 5: "escrita", 6: "escrita",
                   15: "escrita", 16: "escrita"}
MODBUS_AREA = {1: "coil", 2: "discreta", 3: "holding", 4: "input",
               5: "coil", 6: "holding", 15: "coil", 16: "holding"}


def decodificar_modbus(seg):
    d = seg.payload
    pergunta = seg.porta_destino == 502
    if len(d) < 8:               # nem cabe o MBAP + função
        ev = novo_evento(seg, "modbus", pergunta, "outra", 0)
        ev.malformado = True
        return ev
    # MBAP (7 bytes) + função (1 byte), tudo big-endian (">")
    transacao, protocolo, tamanho, unidade, funcao = struct.unpack(
        ">HHHBB", d[:8])
    erro = funcao & 0x80         # bit 7 ligado = resposta de erro
    funcao = funcao & 0x7F
    corpo = d[8:]
    ev = novo_evento(seg, "modbus", pergunta,
                     MODBUS_OPERACAO.get(funcao, "outra"), funcao)
    ev.area = MODBUS_AREA.get(funcao, "")
    ev.transacao, ev.id_protocolo = transacao, protocolo
    ev.tamanho, ev.unidade = tamanho, unidade
    # Protocol ID tem que ser 0 e o Length conta o que vem depois dele
    ev.malformado = protocolo != 0 or len(d) != 6 + tamanho
    chave = ("modbus", seg.ip_origem if pergunta else seg.ip_destino, transacao)
    if pergunta:
        if len(corpo) >= 4:
            ev.endereco, ev.quantidade = struct.unpack(">HH", corpo[:4])
        if funcao in (5, 6):     # escrita simples: o 2o campo é o valor
            ev.valores, ev.quantidade = [ev.quantidade], 1
        elif funcao == 16:       # escrita múltipla: endereço, qtd, nº de bytes, valores
            ev.valores = palavras(corpo[5:])
        PENDENTES[chave] = ev
    else:
        casar(ev, chave)
        if erro:
            ev.status = corpo[0] if corpo else 0
        elif funcao in (3, 4):
            ev.valores = palavras(corpo[1:])
    return ev


DECODIFICADORES[502] = decodificar_modbus


S7_OPERACAO = {0x04: "leitura", 0x05: "escrita",
               0x28: "controle", 0x29: "controle"}
S7_AREA = {0x81: "I", 0x82: "Q", 0x83: "M"}


def decodificar_s7(seg):
    d = seg.payload
    # TPKT: versão 3; a partir do byte 7 tem que haver S7
    if len(d) < 17 or d[0] != 3:
        return None
    if d[5] != 0xF0:             # COTP de dados; senão é conexão
        return None
    tamanho = struct.unpack(">H", d[2:4])[0]
    s7 = d[5 + d[4]:]            # pula TPKT (4) e COTP (1 + d[4])
    rosctr = s7[1]               # 1 = pedido; 2 e 3 = resposta
    if rosctr not in (1, 2, 3):  # 7 = userdata: não decodificado aqui
        return None
    pergunta = rosctr == 1
    pdu_ref, tam_param, tam_dados = struct.unpack(">HHH", s7[4:10])
    inicio = 10 if pergunta else 12   # resposta: +2 bytes de erro
    param = s7[inicio:inicio + tam_param]
    dados = s7[inicio + tam_param:inicio + tam_param + tam_dados]
    funcao = param[0] if param else 0
    ev = novo_evento(seg, "s7", pergunta,
                     S7_OPERACAO.get(funcao, "outra"), funcao)
    ev.transacao, ev.id_protocolo, ev.tamanho = pdu_ref, s7[0], tamanho
    ev.malformado = (tamanho != len(d) or s7[0] != 0x32
                     or len(s7) < inicio + tam_param + tam_dados)
    chave = ("s7", seg.ip_origem if pergunta else seg.ip_destino, pdu_ref)
    if pergunta:
        # Read/Write Var: o 1o item começa em param[2], 12 bytes
        if funcao in (0x04, 0x05) and len(param) >= 14:
            ev.quantidade, db = struct.unpack(">HH", param[6:10])
            ev.area = f"DB{db}" if param[10] == 0x84 else S7_AREA.get(param[10], hex(param[10]))
            ev.endereco = int.from_bytes(param[11:14], "big") >> 3
        if funcao == 0x05:
            ev.valores = palavras(dados[4:])
        PENDENTES[chave] = ev
    else:
        p = casar(ev, chave)
        if p:
            ev.funcao, ev.operacao, ev.area = p.funcao, p.operacao, p.area
        if len(s7) >= 12:
            ev.status = struct.unpack(">H", s7[10:12])[0]   # ex.: 0x8104
        if ev.status == 0 and dados and dados[0] != 0xFF:
            ev.status = dados[0]    # erro do item: 0x0A = não existe
        elif ev.status == 0 and ev.funcao == 0x04:
            ev.valores = palavras(dados[4:])
    return ev


DECODIFICADORES[102] = decodificar_s7


if __name__ == "__main__":
    from captura import ler_arquivo
    for seg in ler_arquivo("exemplo.pcap"):
        print(decodificar(seg))
