"""Roda as suas regras em todas as capturas e mostra quantos alertas cada uma deu em cada pcap.

    python conferir.py                     usa regras.py e a pasta capturas
    python conferir.py --pasta outra       outra pasta de capturas
    python conferir.py --detalhe           mostra o primeiro evento que disparou cada regra
    python conferir.py --regras outro.py   testa outro arquivo de regras

Uma regra precisa: dispara em UMA captura só e nunca na linha de base.
"""

import argparse
import importlib.util
import sys
from collections import Counter
from pathlib import Path

import protocolos
from captura import ler_arquivo

AQUI = Path(__file__).resolve().parent


def rodar(pcap, regras):
    """Roda o pcap do zero: esvazia as perguntas pendentes e a memória das regras."""
    protocolos.PENDENTES.clear()
    regras.__spec__.loader.exec_module(regras)   # roda o arquivo de novo: memória zerada
    contagem, primeiro = Counter(), {}
    for seg in ler_arquivo(str(pcap)):
        ev = protocolos.decodificar(seg)
        if ev is None:
            continue
        for codigo, _nivel, _texto in regras.avaliar(ev):
            contagem[codigo] += 1
            primeiro.setdefault(codigo, ev)
    return contagem, primeiro


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--pasta", default=str(AQUI / "capturas"))
    p.add_argument("--detalhe", action="store_true")
    p.add_argument("--regras", default=str(AQUI / "regras.py"))
    args = p.parse_args()

    spec = importlib.util.spec_from_file_location("regras", args.regras)
    regras = importlib.util.module_from_spec(spec)
    sys.modules["regras"] = regras
    spec.loader.exec_module(regras)
    pasta = Path(args.pasta)
    pcaps = sorted(pasta.glob("*.pcap"), key=lambda f: (f.stem != "linha_de_base", f.stem))
    if not pcaps:
        print("nenhum .pcap em", pasta)
        return
    codigos = [r[0] for r in regras.REGRAS]
    if not codigos:
        print("REGRAS está vazia: escreva as regras em regras.py")
        return

    resultado = {f.stem: rodar(f, regras) for f in pcaps}
    nomes = [f.stem for f in pcaps]
    curto = {n: ("base" if n == "linha_de_base" else n.replace("caso_", "")) for n in nomes}

    print("\nalertas por regra (linha) e captura (coluna)\n")
    print(f"{'':6}" + "".join(f"{curto[n]:>6}" for n in nomes))
    for c in codigos:
        print(f"{c:6}" + "".join(f"{resultado[n][0][c] or '.':>6}" for n in nomes))

    print("\nregras")
    for c in codigos:
        onde = [n for n in nomes if resultado[n][0][c]]
        if not onde:
            diag = "não disparou em nenhuma captura"
        elif "linha_de_base" in onde:
            diag = "FALSO POSITIVO: dispara na linha de base"
        elif len(onde) > 1:
            diag = "imprecisa: dispara em " + ", ".join(onde)
        else:
            diag = "ok: só em " + onde[0]
        print(f"  {c:6} {diag}")

    print("\ncapturas")
    for n in nomes[1:] if nomes[0] == "linha_de_base" else nomes:
        quais = [c for c in codigos if resultado[n][0][c]]
        print(f"  {n:14} " + (", ".join(quais) if quais else "nenhuma regra"))

    if args.detalhe:
        print("\nprimeiro evento de cada alerta")
        for n in nomes:
            for c, ev in resultado[n][1].items():
                print(f"  {n} {c}: {ev}")


if __name__ == "__main__":
    main()
