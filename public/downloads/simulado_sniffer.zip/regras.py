from collections import Counter

# Inventário da planta: IP -> papel.
ATIVOS = {"192.168.0.11": "clp", "192.168.0.12": "clp",
          "192.168.0.29": "engenharia"}
PODEM_ESCREVER = {"clp", "engenharia"}


# ---------------------------------------------------------------- as regras
# Cada regra é uma função que recebe um Evento (ev) e devolve True quando ele é
# suspeito. Depois, cada uma entra na lista REGRAS como
#     ("R01", "ALTA", "o que a regra acha", nome_da_funcao),


REGRAS = [
]


def avaliar(ev):
    alertas = []
    for codigo, nivel, texto, regra in REGRAS:
        if regra(ev):
            alertas.append((codigo, nivel, texto))
    return alertas


class Janela:
    """Conta eventos por (origem, destino, protocolo, operação)."""

    def __init__(self, segundos=10):
        self.segundos = segundos
        self.inicio = None
        self.contagem = Counter()

    def adicionar(self, ev):
        resumo = None
        if self.inicio is None:
            self.inicio = ev.ts
        elif ev.ts - self.inicio >= self.segundos:
            resumo = self.contagem          # a janela acabou
            self.inicio, self.contagem = ev.ts, Counter()
        chave = (ev.origem, ev.destino, ev.protocolo, ev.operacao)
        self.contagem[chave] += 1
        return resumo


# Linha de base: os fluxos que aparecem em TODA janela de 10 s.
# Os alertas dela se chamam LB1 e LB2, para não confundir com as suas R01 a R10.
# É o retrato da ficha: (origem, destino, protocolo, operação).
LINHA_DE_BASE = {
    ("192.168.0.29", "192.168.0.11", "modbus", "leitura"),
    ("192.168.0.11", "192.168.0.29", "modbus", "leitura"),
    ("192.168.0.11", "192.168.0.12", "s7", "leitura"),
    ("192.168.0.12", "192.168.0.11", "s7", "leitura"),
}


def comparar(resumo):
    """Compara uma janela que acabou com a linha de base."""
    vistos = set(resumo)
    alertas = []
    for fluxo in sorted(LINHA_DE_BASE - vistos):
        alertas.append(("LB1", "MEDIA",
                        "fluxo da linha de base sumiu", fluxo))
    for fluxo in sorted(vistos - LINHA_DE_BASE):
        alertas.append(("LB2", "BAIXA",
                        "fluxo fora da linha de base", fluxo))
    return alertas
